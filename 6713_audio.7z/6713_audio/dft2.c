//dft2.c  

#include <stdio.h>
#include <math.h> 

#define PI 3.14159265358979
#define N 100
#define TESTFREQ 900.0
#define SAMPLING_FREQ 8000.0

void main(void)
{

	float samplesR[N];
	float samplesI[N];
	float resultR[N];
	float resultI[N];
	float outR[N];
	float outI[N];
	int k,n;

	{

	  for(n=0 ; n<N ; n++)
	  {
	      samplesR[n] = cos(2*PI*TESTFREQ*n/SAMPLING_FREQ); // Putting sinewav in samples
	      samplesI[n] = 0.0;
	  }
	  
	   for (k=0 ; k<N ; k++) //going through frequency values
	  {
	    resultR[k]=0.0;
	    resultI[k]=0.0;
	
	    for (n=0 ; n<N ; n++) //time steps
	    {
	      resultR[k] += samplesR[n]*cos(2*PI*k*n/N) + samplesI[n]*sin(2*PI*k*n/N); // Eulers relationship , cumulative sum
	      resultI[k] += samplesI[n]*cos(2*PI*k*n/N) - samplesR[n]*sin(2*PI*k*n/N); // imag part
	    }
	  }
	  for (k=0 ; k<N ; k++)
	  {
	    outI[k] = resultI[k]; //buffers for evert k value
	    outR[k] = resultR[k];
	  }
	  
	}
	while(1);                                 //end of while(1) infinite loop
}
